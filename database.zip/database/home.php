<h1> Assignment 4 </h1>
<ol>
	<li><a href = "http://webtech.kettering.edu/~woo2733/Assignment4/database/database/home.php">Home</a><br></li>
	<li><a href = "http://webtech.kettering.edu/~woo2733/Assignment4/database/database/Clients.php">Clients</a><br></li>
	<li><a href = "http://webtech.kettering.edu/~woo2733/Assignment4/database/database/Branch.php">Branch</a><br></li>
	<li><a href = "http://webtech.kettering.edu/~woo2733/Assignment4/database/database/Insurance.php">Insurance Policy</a><br></li>
	<li><a href = "http://webtech.kettering.edu/~woo2733/Assignment4/database/database/Mileage.php">Mileage Plan</a><br></li>
	<li><a href = "http://webtech.kettering.edu/~woo2733/Assignment4/database/database/Reservations.php">Reservations</a><br></li>
</ol>

	