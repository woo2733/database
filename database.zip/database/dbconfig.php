<?php

	$host='localhost';
	$user='woo2733';
	$password='702012733';
	$datbase='woo2733';

	$mysqli = mysqli_connect($host, $user, $password, $datbase);

?>